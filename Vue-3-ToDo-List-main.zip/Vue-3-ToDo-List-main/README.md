# A simple ToDo App with Vue 3

**Demo:  [https://annblok.github.io/Vue-3-ToDo-List](https://annblok.github.io/Vue-3-ToDo-List/)**
____
![Alt-demo](https://i.imgur.com/A1HnwBn.png "View Demo")
